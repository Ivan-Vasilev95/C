#include <iostream>
#include <graphics.h>
#include <cstdlib>
#include <iomanip>
#include <math.h>

using namespace std;

void MinMax(int n,double a[],double& min,double& max){
    max=a[0];
    min=max;
    for(int i=1;i<n;i++){
        if(a[i]>max)
            max=a[i];
        if(a[i]<min)
            min=a[i];
    }
}

void Axis(int dir,int x0,int y0,int P,int D,double Min,double Max,double&S){

    char num[10];
    int i,Br;
    Br=P/D-1;
    double value;
    S=(Max-Min)/P;

    if(dir==0){
        line(x0,y0,x0+P,y0);
        settextjustify(1,2);
        for(i=0;i<=Br;i++){
            line(x0+i*D,y0,x0+i*D,y0+5);
            value=Min+D*i*S;
            gcvt(value,6,num);
            outtextxy(x0+i*D,y0+5,num);
        }
    }
    else{
        line(x0,y0,x0,y0-P);
        settextjustify(2,1);
        for(i=0;i<=Br;i++){
            line(x0,y0-i*D,x0-5,y0-i*D);
            value=Min+D*i*S;
            gcvt(value,6,num);
            outtextxy(x0-5,y0-i*D,num);
        }
    }
}

void Point(int type_point,short dp_line,int n,double VhodX[],double VhodY[],int x0,int y0,double minx,double miny,double sx,double sy){

        for(int i=0;i<n;i++){
            int xp=x0+(VhodX[i]-minx)/sx;
            int yp=y0-(VhodY[i]-miny)/sy;

            switch(type_point){
            case 0:
                putpixel(xp,yp,2);
            break;
            case 1:
                line(xp,yp+1,xp,yp-1);
                line(xp-1,yp,xp+1,yp);
            break;
            case 2:
                circle(xp,yp,6);
                break;
            case 3:
                bar(xp-1,yp-1,xp+1,yp+1);
                break;

            }
            if(dp_line==1){
                if(i==0)
                    moveto(xp,yp);
                else
                    lineto(xp,yp);
            }
            getch();
}
}
int main()
{
   initwindow(800,600,"Ex_2");
   setfillstyle(1,GREEN);

   double VhodX[6]={0.3,4.6,2.1,0.8,23.9,6.2};
   double VhodY[6]={0.6,5.2,12.4,4.6,7.7,8.2};

   double minX,minY,maxX,maxY,Sx,Sy;
   int n=6;

   MinMax(n,VhodX,minX,maxX);
   MinMax(n,VhodY,minY,maxY);

   Axis(0,40,460,500,40,minX,maxX,Sx);
   Axis(1,40,460,420,35,minY,maxY,Sy);

   setcolor(10);
   Point(2,0,n,VhodX,VhodY,40,460,minX,minY,Sx,Sy);


   getch();
}
